<!DOCTYPE HTML>
<html>

<head>
    <meta charset='utf-8'>
    <title>This greeting page</title>
    <style type='text/css'>
    body {
        margin: 0;
        padding: 0;
        background-color: cyan;
    }

    div {
        display: flex;
        justify-content: center;
        font-size: 120%;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        color: #333366;
    }

    h1 {
        font-size: 100%;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        color: #333366;
    }
    </style>
</head>

<body>
    <div>
        <h1>Это страница приветствия к заданию №2 п.п. 1.1.</h1>
    </div>
    <div>
        <p>Данная сраница создана для проработки темы второго урока <br>
            "Роутинг.Использование контроллеров."
        </p>
    </div>

</body>

</html>";