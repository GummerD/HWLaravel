<?=



    $url = $_SERVER['QUERY_STRING'];
    $str = $_GET;
    dump($str);
    dump($category);
?>