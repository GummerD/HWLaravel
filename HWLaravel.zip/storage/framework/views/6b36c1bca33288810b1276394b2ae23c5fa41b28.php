<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
  <div style="border: 1px solid green">
      <h2><?php echo e($n['title']); ?></h2>
      <p><?php echo e($n['description']); ?></p>
      <div><strong><?php echo e($n['author']); ?> (<?php echo e($n['created_at']); ?>)</strong>
        <a href="<?php echo e(route('news.show', ['id' => $n['id']])); ?>">Далее</a>
      </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /application/resources/views/news/lesson_3/index.blade.php ENDPATH**/ ?>